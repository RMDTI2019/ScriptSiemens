import os
from CDRLine import CDRLine
import sys
import re

'''
script que recive 3 argumentos que son la carpeda de los archivos y las extensiones que quiere revisar 
'''
class CDRSimens:
    def CDRSiemens(self):
        try:
            listaArg = sys.argv

            if len(listaArg) == 4:
                baseFolder = listaArg[1]
                fileExten = listaArg[2]
                cantDigExten = listaArg[3]

                if (len(baseFolder) >0 and len(fileExten) > 0 and len(cantDigExten) > 0):
                    self.InicioProceso(baseFolder,fileExten,cantDigExten)
            else:
                print("\tERROR: el numero de parametros no es correcto, se esparaban 3 parametros")            

        except:
            print ("Error en el método: CDRSiemens\n")
            return
    
    def InicioProceso(self,baseFolder, fileExten,CantDigExten):
        try:
            if (os.path.exists(baseFolder)):
                listaArchivos = [x for x in os.listdir(baseFolder) if x.endswith(fileExten)]
                
                if (len(listaArchivos )> 0):
                    
                    for arch in listaArchivos:
                        self.ProcesaArchivo(os.path.abspath(os.path.join(baseFolder,arch)),CantDigExten)
                else:
                    print("\lista de archivos esta vacia")
        except:
            print("\tERROR en el método InicioProceso ")
            return

    def ProcesaArchivo(self, archivo,CantDigExten):
        try:
            
            if (os.path.isfile(archivo)):
                dataFile = open(archivo,'r')
                print(archivo)
                self.ProcesarLineas(dataFile,CantDigExten) 
                dataFile.close()   
            else:
                print("\tERROR: Error en el procesamiento del archivo. " +archivo)            
        except:
            print("ERROR en el método ProcesaArchivo: " % archivo)        
            return

    def ProcesarLineas(self,dataFile,CantDigExten):
        try:
            for  line in dataFile:
                line = re.sub('\n',' ',line)
                self.ValidaLinea(line,CantDigExten)
        except:
            print("\tERROR en LeerArchivo")
            return

    def ValidaLinea(self,line,CantDigExten):
        try:
            regex = r"\s*(?P<exten>52[\d]{10})\s{1,}(?P<dir>[^\s]{1,2})\s{1,}(?P<no>\d{1,})\s*(?P<fecha>\d{4}-\d{2}-\d{2})\s{1,}(?P<hora>\d{2}:\d{2})\s{1,}(?P<dur>\d{2}:\d{2}:\d{2})\s{1,}(?P<cod>\d{1,})?\s{1,}\s*(?P<tro>[eE]p[^\s]*)?\s*"
            
            objMatch = re.match(regex,line)
            
            if objMatch is not None:
                
                objCDRLine = CDRLine();

                objCDRLine.Line = line
                objCDRLine.Exten = objMatch.group("exten")
                objCDRLine.Dir = objMatch.group("dir")
                objCDRLine.No = objMatch.group("no")
                objCDRLine.Fecha = objMatch.group("fecha")
                objCDRLine.Hora = objMatch.group("hora")
                objCDRLine.Dur = objMatch.group("dur")
                objCDRLine.Cod = objMatch.group("cod")
                objCDRLine.Tro = objMatch.group("tro")
                
                self.ProcesaObjCDR(objCDRLine,CantDigExten)
                
        except:
            print("Error en ValidaLinea")
            return

    def ProcesaObjCDR(self,objCDRLine,CantDigExten):
        try:
            self.BuscaTipoLlamada(objCDRLine,CantDigExten)
        except:
            return

    def BuscaTipoLlamada(self,objCDRLine,CantDigExten):
        try:
            if(len(objCDRLine.Exten.strip()) == 12 and objCDRLine.Exten.startswith("52") and len(objCDRLine.No.strip()) == 12  and objCDRLine.No.startswith("52")):
                #se  tiene que obtener los ultimos digitos de la extension y del numero marcado 0 y 2, si troncal es none o vacio se tiene que cambiar  por el valor 4013
                
                objCDRLine.TipoLlamada = "ENLACE"
                inicioExten  = len(objCDRLine.Exten)-int(CantDigExten)
                inicioNo  = len(objCDRLine.No)-int(CantDigExten)

                objCDRLine.Exten =  objCDRLine.Exten[inicioExten:]
                objCDRLine.No =  objCDRLine.Exten[inicioNo:]


                if(objCDRLine.Tro == None or objCDRLine.Tro ):                
                    troncal

            elif (objCDRLine.No.startswith("1") and len(objCDRLine.No) == 11):
                objCDRLine.TipoLlamada = "INTERNACIONAL"
            elif (len(objCDRLine.No) == 10):
                objCDRLine.TipoLlamada = "ENTRADA"
            else:
                objCDRLine.TipoLlamada = "NO IDENT"
        except:
            return
                
obj = CDRSimens();
obj.CDRSiemens()

