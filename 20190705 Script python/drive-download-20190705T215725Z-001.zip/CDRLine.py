class CDRLine:
    def __init__(self):
        self.Exten = ""
        self.Dir = ""
        self.No = ""
        self.Fecha= ""
        self.Hora= ""
        self.Dur  = ""
        self.Cod =  ""
        self.Tro = ""
        self.Line = ""
        self.TipoLlamada = ""
        